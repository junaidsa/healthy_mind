<div class="appHeader">
    <div class="pageTitle">
        <img src="{{asset('public')}}/assets/img/logo.png" alt="logo" class="logo">
    </div>
    <div class="right">
        <a href="app-notifications.html" class="headerButton">
            <ion-icon class="icon" name="notifications-outline"></ion-icon>
            <span class="badge badge-danger"></span>
        </a>
        <a href="app-settings.html" class="headerButton">
            <img src="{{asset('public')}}/assets/img/sample/avatar/avatar1.jpg" alt="image" class="imaged w32">
        </a>
    </div>
</div>