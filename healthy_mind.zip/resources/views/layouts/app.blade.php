@php
$medicne = DB::table('medicines')->whereNull('deleted_at')->get();
 foreach($medicne as $key => $med){
     $opening_stock = DB::table('stock_history')->where('medicine_id', $med->id)->where('type', 'opening')->where('date', date('Y-m-d'))->first();
        if (!isset($opening_stock)){
            $stock = DB::table('batches')->where('quantity', '>' , '0')->where('medicine_id', $med->id)->sum('quantity');
            DB::table('stock_history')->insert([
                'type' => 'opening',
                'medicine_id' => $med->id,
                'qty' => $stock,
                'date' => date('Y-m-d'),
        ]);
        }

 }
@endphp

<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>@yield('title', 'Healthy Mind')</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    <meta name="csrf-token" content="{{csrf_token()}}" />
    <!-- Bootstrap Css -->
    <link href="{{ asset('public') }}/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="{{ asset('public') }}/assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="{{ asset('public') }}/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="{{ asset('public') }}/assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <link rel="stylesheet" type="text/css" href="{{ asset('public') }}/assets/libs/toastr/build/toastr.min.css">
            <script src="{{ asset('public') }}/assets/libs/toastr/build/toastr.min.js"></script>
            <script src="{{ asset('public') }}/assets/js/pages/toastr.init.js"></script>
    <link href="{{ asset('public') }}/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="{{ asset('public') }}/assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <link href="{{ asset('public') }}/assets/libs/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="{{ asset('public') }}/assets/libs/%40chenfengyuan/datepicker/datepicker.min.css">
</head>
<style>
    .navbar-brand-box {
    background-color: #474747!important;
    padding-top: .8rem;
    font-size: 1.3rem;
    font-weight: bold;
    color: #fff; /* or any other color you want */
  text-decoration: none;
}
.hover-color{
    background: #fff;
}

.navbar-brand-box.navbar-brand {
  font-family: Arial, sans-serif; /* or any other font family you want */
  letter-spacing: 1px; /* adjust the letter spacing to your liking */
}
</style>
<script>
    toastr.options = {
      "closeButton": true,
      "debug": false,
      "newestOnTop": false,
      "progressBar": false,
      "positionClass": "toast-top-right",
      "preventDuplicates": false,
      "onclick": null,
      "showDuration": 300,
      "hideDuration": 1000,
      "timeOut": 5000,
      "extendedTimeOut": 1000,
      "showEasing": "swing",
      "hideEasing": "linear",
      "showMethod": "fadeIn",
      "hideMethod": "fadeOut"
    }
</script>
@yield('css')
    <body data-sidebar="dark" data-layout-mode="light">
        <!-- Begin page -->
        <div id="layout-wrapper">
            <div id="layout-wrapper">
                <header id="page-topbar">
                    <div class="navbar-header">
                        <div class="d-flex">
                            <!-- LOGO -->
                            <div class="navbar-brand-box">
                                <a class="navbar-brand" href="#">Healthy Mind</a>
                            </div>


                            <div class="dropdown dropdown-mega d-none d-lg-block ms-2">
                                <button type="button" class="btn header-item waves-effect" data-bs-toggle="dropdown" aria-haspopup="false" aria-expanded="false">
                                    {{-- <span key="t-megamenu">Mega Menu</span> --}}
                                    {{-- <i class="mdi mdi-chevron-down"></i> --}}
                                </button>
                            </div>
                        </div>

                        <div class="d-flex">

                            <div class="dropdown d-inline-block d-lg-none ms-2">
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0"
                                    aria-labelledby="page-header-search-dropdown">

                                    <form class="p-3">
                                        <div class="form-group m-0">
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                                <div class="input-group-append">
                                                    <button class="btn btn-primary" type="submit"><i class="mdi mdi-magnify"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="dropdown d-none d-lg-inline-block ms-1">
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
                                    <div class="px-lg-2">
                                        <div class="row g-0">
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/github.png" alt="Github">
                                                    <span>GitHub</span>
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/bitbucket.png" alt="bitbucket">
                                                    <span>Bitbucket</span>
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/dribbble.png" alt="dribbble">
                                                    <span>Dribbble</span>
                                                </a>
                                            </div>
                                        </div>

                                        <div class="row g-0">
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/dropbox.png" alt="dropbox">
                                                    <span>Dropbox</span>
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/mail_chimp.png" alt="mail_chimp">
                                                    <span>Mail Chimp</span>
                                                </a>
                                            </div>
                                            <div class="col">
                                                <a class="dropdown-icon-item" href="#">
                                                    <img src="{{ asset('public') }}/assets/images/brands/slack.png" alt="slack">
                                                    <span>Slack</span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown d-none d-lg-inline-block ms-1">
                                <button type="button" class="btn header-item noti-icon waves-effect" data-bs-toggle="fullscreen">
                                    <i class="bx bx-fullscreen"></i>
                                </button>
                            </div>



                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img class="rounded-circle header-profile-user" src="{{ asset('public') }}/assets/images/users/avatar-1.jpg"
                                        alt="Header Avatar">
                                    <span class="d-none d-xl-inline-block ms-1" key="t-henry">Henry</span>
                                    <i class="mdi mdi-chevron-down d-none d-xl-inline-block"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a class="dropdown-item text-danger" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i> <span key="t-logout">Logout</span></a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </div>

                            {{-- <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item noti-icon right-bar-toggle waves-effect">
                                    <i class="bx bx-cog bx-spin"></i>
                                </button>
                            </div> --}}

                        </div>
                    </div>
                </header>
                @if(session('success'))
                <script>
                  toastr["success"]("{{ session('success') }}");
                </script>
              @endif
                <!-- ========== Left Sidebar Start ========== -->
                <div class="vertical-menu">

                    <div data-simplebar class="h-100">

                        <!--- Sidemenu -->
                        <div id="sidebar-menu">
                            <!-- Left Menu Start -->
                            <ul class="metismenu list-unstyled" id="side-menu">
                                <li class="menu-title" key="t-menu">Menu</li>

                                <li>
                                    <a href="{{url('home')}}" class="{{ Request::is('home') ? 'mm-active' : ''}}">
                                        <i class="bx bx-home-circle"></i>
                                        <span key="t-dashboards">Dashboards</span>
                                    </a>
                                </li>

                                <li  class="{{ Request::is('patients') || Request::is('patients/create') || Request::is('patients/*') ? 'mm-active' : '' }}">
                                    <a href="{{url('patients')}}">
                                        <i class="bx bx-layout"></i>
                                        <span key="t-layouts">Patients</span>
                                    </a>

                                </li>

                                {{-- <li class="menu-title" key="t-apps">Apps</li> --}}


                                <li class="{{ Request::is('medicines') || Request::is('medicines/create') || Request::is('medicines/*') ? 'mm-active' : '' }}">
                                    <a href="{{url('medicines')}}" >
                                        <i class="bx bx-layout"></i>
                                        <span key="t-dashboards">Medicine</span>
                                    </a>
                                </li>

                                <li  class="{{ Request::is('dispense') || Request::is('dispense/create') || Request::is('dispense/*') ? 'mm-active' : '' }}">
                                    <a href="{{ url('/dispense') }}">
                                        <i class="bx bx-layout"></i>
                                        <span key="t-layouts">Dispense</span>
                                    </a>
                                </li>
                                <li class="{{ Request::is('billbook') || Request::is('billbook/create') || Request::is('billbook/*') ? 'mm-active' : '' }}">
                                    <a href="{{ url('billbook') }}" class="waves-effect">
                                        <i class="bx bx-layout"></i>
                                        <span key="t-chat">Bill Book</span>
                                    </a>
                                </li >
                                <li class="{{ Request::is('stockbook') || Request::is('stockbook/create') || Request::is('stockbook/*') ? 'mm-active' : '' }}">
                                    <a href="{{ url('stockbook') }}" class="waves-effect">
                                        <i class="bx bx-layout"></i>
                                        <span key="t-chat">Stock Book</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!-- Sidebar -->
                    </div>
                </div>
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                <!-- Left Sidebar End -->
                @yield('main')
                {{-- <footer class="footer">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-sm-6">
                                <script>
                                    document.write(new Date().getFullYear())
                                </script> © Healthy Mind.
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Healthy Mind
                                </div>
                            </div>
                        </div>
                    </div>
                </footer> --}}
            </div>
            </div>
            <!-- END layout-wrapper -->

        <!-- Right Sidebar -->
        <div class="right-bar">
            <div data-simplebar class="h-100">
                <div class="rightbar-title d-flex align-items-center px-3 py-4">

                    <h5 class="m-0 me-2">Settings</h5>

                    <a href="javascript:void(0);" class="right-bar-toggle ms-auto">
                        <i class="mdi mdi-close noti-icon"></i>
                    </a>
                </div>

                <!-- Settings -->
                <hr class="mt-0" />
                <h6 class="text-center mb-0">Choose Layouts</h6>

                <div class="p-4">
                    <div class="mb-2">
                        <img src="{{ asset('public') }}/assets/images/layouts/layout-1.jpg" class="img-thumbnail" alt="layout images">
                    </div>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="light-mode-switch" checked>
                        <label class="form-check-label" for="light-mode-switch">Light Mode</label>
                    </div>

                    <div class="mb-2">
                        <img src="{{ asset('public') }}/assets/images/layouts/layout-2.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-mode-switch">
                        <label class="form-check-label" for="dark-mode-switch">Dark Mode</label>
                    </div>

                    <div class="mb-2">
                        <img src="{{ asset('public') }}/assets/images/layouts/layout-3.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input theme-choice" type="checkbox" id="rtl-mode-switch">
                        <label class="form-check-label" for="rtl-mode-switch">RTL Mode</label>
                    </div>

                    <div class="mb-2">
                        <img src="{{ asset('public') }}/assets/images/layouts/layout-4.jpg" class="img-thumbnail" alt="layout images">
                    </div>
                    <div class="form-check form-switch mb-5">
                        <input class="form-check-input theme-choice" type="checkbox" id="dark-rtl-mode-switch">
                        <label class="form-check-label" for="dark-rtl-mode-switch">Dark RTL Mode</label>
                    </div>


                </div>

            </div> <!-- end slimscroll-menu-->
        </div>
        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>
        <script src="{{ asset('public') }}/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/simplebar/simplebar.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/node-waves/waves.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
        <script src="{{ asset('public') }}/assets/libs/apexcharts/apexcharts.min.js"></script>
        <script src="{{ asset('public') }}/assets/js/pages/dashboard-job.init.js"></script>
                <script src="{{ asset('public') }}/assets/libs/dropzone/min/dropzone.min.js"></script>
                <script src="{{ asset('public') }}/assets/libs/toastr/build/toastr.min.js"></script>
                <script src="{{ asset('public') }}/assets/js/pages/toastr.init.js"></script>
                <script src="{{ asset('public') }}/assets/js/app.js"></script>
                <script src="{{ asset('public') }}/assets/js/app.js"></script>
                    <!-- form repeater js -->
                <script src="{{ asset('public') }}/assets/libs/jquery.repeater/jquery.repeater.min.js"></script>
                 <script src="{{ asset('public') }}/assets/js/pages/form-repeater.int.js"></script>
         <!-- Sweet Alerts js -->
        <script src="{{ asset('public') }}/assets/libs/sweetalert2/sweetalert2.min.js"></script>
        <script src="{{ asset('public') }}/assets/js/pages/sweet-alerts.init.js"></script>
        <script>
            $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        </script>
        @yield('customJs')

</body>

<!-- Mirrored from themesbrand.com/skote/layouts/dashboard-job.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 07 Aug 2023 16:08:27 GMT -->
</html>
    {{-- @include('layout/header'); --}}
    {{-- @include('layout/footer') --}}
